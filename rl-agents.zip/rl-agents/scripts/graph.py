import json
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import argparse

# Set up argument parser
parser = argparse.ArgumentParser(description='Visualize performance metrics from a JSON file.')
parser.add_argument('file_path', type=str, help='Path to the JSON file containing episode data.')
args = parser.parse_args()

# Load JSON data from file provided by command line argument
with open(args.file_path, 'r') as file:
    data = json.load(file)

# Convert data into a DataFrame
df = pd.DataFrame({
    'episode_rewards': data['episode_rewards'],
    'episode_lengths': data['episode_lengths'],
    'discounted_rewards': [np.sum([r * (0.95 ** i) for i, r in enumerate(ep)]) for ep in data['episode_rewards_']],
    'episode_seeds': data['episode_seeds'],
    'episode_velocity': [np.mean(ep) if ep else 0 for ep in data['episode_velocity']],
    'episode_crashed': [any(ep) for ep in data['episode_crashed']],
    'episode_action_counts': [len(ep) for ep in data['episode_action']],
    'episode_cost': [np.mean(ep) if ep else 0 for ep in data['episode_cost']]  # Calculating average cost per episode
})

# Setup for multiple subplots
fig, axs = plt.subplots(nrows=4, ncols=2, figsize=(15, 20))
fig.suptitle('Performance Metrics Across Episodes', fontsize=16)

# Plotting each metric
axs[0, 0].plot(df['episode_rewards'], label='Episode Rewards', color='blue')
axs[0, 0].set_title('Episode Rewards')
axs[0, 0].set_xlabel('Episode')
axs[0, 0].set_ylabel('Rewards')
axs[0, 0].grid(True)

axs[0, 1].plot(df['episode_lengths'], label='Episode Lengths', color='red')
axs[0, 1].set_title('Episode Lengths')
axs[0, 1].set_xlabel('Episode')
axs[0, 1].set_ylabel('Length')
axs[0, 1].grid(True)

axs[1, 0].plot(df['discounted_rewards'], label='Discounted Rewards', color='green')
axs[1, 0].set_title('Discounted Rewards')
axs[1, 0].set_xlabel('Episode')
axs[1, 0].set_ylabel('Discounted Reward')
axs[1, 0].grid(True)

axs[1, 1].plot(df['episode_seeds'], label='Episode Seeds', color='purple')
axs[1, 1].set_title('Episode Seeds')
axs[1, 1].set_xlabel('Episode')
axs[1, 1].set_ylabel('Seeds')
axs[1, 1].grid(True)

axs[2, 0].plot(df['episode_velocity'], label='Average Velocity', color='orange')
axs[2, 0].set_title('Average Velocity')
axs[2, 0].set_xlabel('Episode')
axs[2, 0].set_ylabel('Velocity')
axs[2, 0].grid(True)

axs[2, 1].plot(df['episode_crashed'], label='Crashes', color='black')
axs[2, 1].set_title('Crashes')
axs[2, 1].set_xlabel('Episode')
axs[2, 1].set_ylabel('Crash Occurrences')
axs[2, 1].grid(True)

axs[3, 0].plot(df['episode_action_counts'], label='Action Counts', color='magenta')
axs[3, 0].set_title('Action Counts')
axs[3, 0].set_xlabel('Episode')
axs[3, 0].set_ylabel('Number of Actions')
axs[3, 0].grid(True)

axs[3, 1].plot(df['episode_cost'], label='Average Episode Cost', color='cyan')
axs[3, 1].set_title('Average Episode Cost')
axs[3, 1].set_xlabel('Episode')
axs[3, 1].set_ylabel('Cost')
axs[3, 1].grid(True)

# Add legends and adjust layout
for ax in axs.flat:
    ax.legend()

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()
