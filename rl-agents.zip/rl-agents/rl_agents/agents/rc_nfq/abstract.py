from abc import ABC
import numpy as np
import logging
import torch
import torch.nn as nn
from collections import namedtuple, deque
import random

from rl_agents.agents.common.abstract import AbstractStochasticAgent
from rl_agents.agents.common.utils import choose_device
from rl_agents.agents.deep_q_network.abstract import AbstractDQNAgent
from rl_agents.agents.fitted_q.abstract import AbstractFTQAgent

logger = logging.getLogger(__name__)
Transition = namedtuple('Transition', ('state', 'action', 'next_state', 'reward', 'done'))

class AbstractRCNFQAgent(AbstractDQNAgent, AbstractFTQAgent, ABC):
    """
    Abstract Regularized Convolutional Neural Fitted Q (RC-NFQ) agent class,
    combining the Q-learning updates of DQN and the batch learning approaches of FQ.
    """

    def __init__(self, env, config=None):
        super(AbstractRCNFQAgent, self).__init__(env, config)
        self.memory = deque(maxlen=config.get("memory_size", 10000))  # experience replay buffer
        self.batch_size = config.get("batch_size", 32)
        self.discount_factor = config.get("discount_factor", 0.99)
        self.memory = deque(maxlen=config.get("memory_size", 10000))
        self.epsilon = config.get("epsilon", 0.1)
        self.state_dim = env.observation_space.shape
        self.nb_actions = env.action_space.n
        self.convolutional = True
        self.device = choose_device(config["device"])
        self.initialize_model()

    def initialize_model(self):
        """
        Initialize or reset the model. Needs to be implemented by the concrete subclass.
        """
        raise NotImplementedError

    def push_memory(self, state, action, next_state, reward, done):
        """
        Store transitions in the memory.
        """
        self.memory.append(Transition(state, action, next_state, reward, done))

    def sample_minibatch(self):
        """
        Sample a minibatch from the memory.
        """
        return random.sample(self.memory, self.batch_size) if len(self.memory) >= self.batch_size else None

    def update_model(self):
        """
        Update the model using the sampled minibatch. Needs to be implemented by the concrete subclass.
        """
        raise NotImplementedError

    def select_action(self, state):
        """
        Select an action based on the current state, using epsilon-greedy or other policies.
        """
        if np.random.rand() < self.epsilon:
            return random.randint(0, self.nb_actions - 1)
        else:
            return self.get_max_action(state)

    def get_max_action(self, state):
        """
        Get the action with the maximum Q-value for a given state.
        """
        raise NotImplementedError

    def compute_bellman_residual(self, batch, target_state_action_value=None):
        """
        Compute the Bellman residual for a batch of transitions, optionally using target state-action values.
        """
        states, actions, rewards, next_states, dones = zip(*batch)
        states = torch.tensor(np.array(states), dtype=torch.float32)
        next_states = torch.tensor(np.array(next_states), dtype=torch.float32)
        actions = torch.tensor(actions, dtype=torch.long)
        rewards = torch.tensor(rewards, dtype=torch.float32)
        dones = torch.tensor(dones, dtype=torch.bool)

        current_q_values = self.model(states).gather(1, actions.unsqueeze(1)).squeeze(1)
        max_next_q_values = self.model(next_states).max(1)[0]
        expected_q_values = rewards + self.discount_factor * max_next_q_values * (~dones)

        loss = nn.functional.mse_loss(current_q_values, expected_q_values)
        return loss

    def update_target_network(self):
        """
        Optionally update the target network with weights from the main network.
        """
        if hasattr(self, 'target_model'):
            self.target_model.load_state_dict(self.model.state_dict())

    @classmethod
    def default_config(cls):
        """
        Default configuration for RC-NFQ agent, merging DQN and FQ settings.
        """
        cfg = super(AbstractRCNFQAgent, cls).default_config()
        cfg.update({
            "memory_size": 10000,
            "batch_size": 32,
            "discount_factor": 0.99,
            "learning_rate": 0.01,
            "target_network_update_freq": 10,
            "model": "ConvolutionalNFQ",
            "validation": True
        })
        return cfg
