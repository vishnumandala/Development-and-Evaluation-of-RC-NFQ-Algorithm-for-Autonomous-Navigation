import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import logging
from collections import namedtuple, deque
import random
import pickle
from rl_agents.agents.common.optimizers import optimizer_factory
from rl_agents.agents.common.utils import load_pytorch
from rl_agents.agents.rc_nfq.abstract import AbstractRCNFQAgent

logger = logging.getLogger(__name__)

# Transition data structure for storing experiences.
Transition = namedtuple('Transition', ('state', 'action', 'next_state', 'reward', 'done'))

class ReplayMemory:
    """A simple storage for storing experiences of the agent."""

    def __init__(self, capacity):
        """
        Initializes the ReplayMemory with a specified capacity.
        
        Args:
            capacity (int): Maximum number of transitions to hold in the memory.
        """
        self.memory = deque([], maxlen=capacity)

    def push(self, *args):
        """Saves a transition."""
        self.memory.append(Transition(*args))

    def sample(self, batch_size):
        """
        Samples a batch of transitions from the memory.
        
        Args:
            batch_size (int): Size of the batch to sample.
        
        Returns:
            list: A list of randomly sampled transitions.
        """
        return random.sample(self.memory, batch_size)

    def __len__(self):
        """Returns the current size of the memory."""
        return len(self.memory)

class ConvolutionalNFQ(nn.Module):
    """Convolutional Neural Network for NFQ-based approaches."""
    
    def __init__(self, state_dim, action_dim, lr=0.01):
        """
        Initializes a Convolutional NFQ model.
        
        Args:
            state_dim (tuple): The dimensions of the state space.
            action_dim (int): The dimension of the action space.
            lr (float): Learning rate for the optimizer.
        """
        super(ConvolutionalNFQ, self).__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim

        # Define the convolutional layers.
        self.cnn = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Dropout(0.25),
            nn.Conv2d(16, 32, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Dropout(0.25),
            nn.Flatten()
        )
        
        # Define the fully connected layers for action value estimation.
        self.q_fn = nn.Sequential(
            nn.Linear(32 * 11 * 11 + action_dim, 256), 
            nn.ReLU(),
            nn.Dropout(0.25),
            nn.Linear(256, 1)
        )
        
        # Configure the optimizer with a factory method.
        self.optimizer = optimizer_factory("RMS_PROP", self.parameters(), lr=lr)

    def forward(self, state, action):
        """
        Forward pass for the NFQ network.

        Args:
            state (torch.Tensor): The input state.
            action (torch.Tensor): The action taken.

        Returns:
            torch.Tensor: The predicted Q-value.
        """
        state_features = self.cnn(state)
        x = torch.cat([state_features, action], dim=1)
        return self.q_fn(x)

class RCNFQAgent(AbstractRCNFQAgent):
    """Reinforcement Learning agent implementing Regularized Convolutional NFQ."""
    
    def __init__(self, env, config):
        """
        Initialize the RCNFQAgent with an environment and a configuration.

        Args:
            env (Environment): The environment the agent will interact with.
            config (dict): Configuration dictionary specifying hyperparameters.
        """
        super(RCNFQAgent, self).__init__(env, config)
        load_pytorch()
        self.config = config
        self.model = ConvolutionalNFQ(env.state_dim, env.action_space.n, lr=config['lr'])
        self.target_model = ConvolutionalNFQ(env.state_dim, env.action_space.n, lr=config['lr'])
        self.target_model.load_state_dict(self.model.state_dict())
        self.target_model.eval()

        self.memory = ReplayMemory(config['memory_capacity'])
        self.epsilon = config.get('epsilon', 0.1)
        self.lr = config.get('lr', 0.01)
        self.discount_factor = config.get('discount_factor', 0.99)
        self.target_network_update_freq = config.get('target_network_update_freq', 10)
        self.train_iters = config.get('train_iters', 50)

    def initialize_model(self):
        """Initialize or reset the model and target model."""
        self.model.reset()
        self.target_model.load_state_dict(self.model.state_dict())
        self.target_model.eval()

    def train(self, episodes, batch_size):
        """
        Train the agent for a specified number of episodes.

        Args:
            episodes (int): Number of episodes to train the agent.
            batch_size (int): Size of the batch used to update the agent.
        """
        for episode in range(episodes):
            state = self.env.reset()
            total_loss = 0
            temp_memory = []
            while True:
                action = self.select_action(state)
                next_state, reward, done, _ = self.env.step(action)
                self.memory.push(state, action, next_state, reward, done)
                state = next_state

                if len(self.memory) > batch_size:
                    loss = self.update_model(batch_size)
                    total_loss += loss
                
                if done:
                    break

            self.memory.extend(temp_memory)
            for _ in range(self.config['train_iters']):
                batch = self.memory.sample(batch_size)
                self.update_model(batch)
                if _ % self.config['target_network_update_freq'] == 0:
                    self.update_target_network()

            logger.info(f'Episode {episode + 1}: Total Loss {total_loss:.4f}')

    def update_model(self, batch_size):
        """
        Update the model using a batch of transitions.
        
        Args:
            batch_size (int): Size of the batch to sample.
            
        Returns:
            float: The loss value for the current batch.
        """
        if len(self.memory) < batch_size:
            return 0  # Not enough samples

        transitions = self.memory.sample(batch_size)
        batch = Transition(*zip(*transitions))

        # Convert batch array of transitions to Torch tensors
        states = torch.tensor(np.array(batch.state), dtype=torch.float32, device=self.device)
        next_states = torch.tensor(np.array(batch.next_state), dtype=torch.float32, device=self.device)
        actions = torch.tensor(batch.action, dtype=torch.long, device=self.device).unsqueeze(-1)
        rewards = torch.tensor(batch.reward, dtype=torch.float32, device=self.device)

        # Compute current Q values: Q(s, a; theta)
        current_q_values = self.model(states).gather(1, actions)

        # Compute next Q values: max_a' Q(s', a'; theta^-) from target network
        next_q_values = self.target_model(next_states).max(1)[0].detach()

        # Compute the expected Q values
        expected_q_values = rewards + (self.discount_factor * next_q_values * (~torch.tensor(batch.done, device=self.device)))

        # Compute Huber loss between current and expected Q values
        loss = nn.functional.mse_loss(current_q_values, expected_q_values.unsqueeze(1))
        
        # Perform gradient descent step
        self.model.optimizer.zero_grad()
        loss.backward()
        self.model.optimizer.step()

        return loss.item()

    def update_target_network(self):
        """Update the weights of the target network with those from the model."""
        self.target_model.load_state_dict(self.model.state_dict())

    def select_action(self, state):
        """
        Select an action based on the current state.

        Args:
            state (array): The current state from the environment.

        Returns:
            int: The action selected by the agent.
        """
        if np.random.rand() <= self.epsilon:
            return random.randrange(self.nb_actions)
        else:
            self.model.eval()
            with torch.no_grad():
                state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
                action_values = self.model(state)
            self.model.train()
            return torch.argmax(action_values).item()

    def get_max_action(self, state):
        """
        Get the action with the maximum Q-value for a given state.
        
        Args:
            state (array): The current state from the environment.
        
        Returns:
            int: The action with the maximum Q-value.
        """
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            return self.model(state).argmax().item()

    def decay_epsilon(self):
        """Decay the exploration epsilon if it is above the minimum threshold."""
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    def save(self, filename):
        """
        Save the model state to a file.

        Args:
            filename (str): Path to the file where the model state will be saved.
        """
        state = {
            'state_dict': self.model.state_dict(),
            'optimizer': self.model.optimizer.state_dict()
        }
        torch.save(state, filename)

    def load(self, filename):
        """
        Load the model state from a file.

        Args:
            filename (str): Path to the file from which to load the model state.
        """
        checkpoint = torch.load(filename)
        self.model.load_state_dict(checkpoint['state_dict'])
        self.model.optimizer.load_state_dict(checkpoint['optimizer'])
